# 50 historias + 20 historias en video para @resto.ga

Todo está en formato 9:16 (1080×1920), listo para subir como historia desde el celular. Nada de esto está publicado: lo subís vos cuando quieras.

## Cómo subir una historia (paso a paso)
1. Descomprimí el zip en el celular y guardá las imágenes o videos en la galería (en iPhone: abrir el archivo → Compartir → Guardar imagen o Guardar video).
2. En Instagram, entrá a @resto.ga y deslizá a la derecha desde el inicio, o tocá tu foto de perfil con el **+**.
3. Elegí la imagen o el video de la galería.
4. Agregá lo que diga la tabla de abajo (sticker de link, encuesta o música).
5. Tocá **Tu historia** para publicarla.

**Sticker de link (recomendado en casi todas):** ícono del sticker (la carita cuadrada arriba) → **Enlace** → `https://restoga.com` → texto del sticker: *Conocé Restoga*. Ubicalo arriba del botón rojo "restoga.com" o tapándolo, en la parte de abajo, que es donde queda libre.

**Zona segura:** dejá libres los 250 px de arriba y los 300 de abajo de la pantalla. Ahí Instagram pone tu nombre y la barra para responder. Las historias ya están armadas respetando eso.

## Ritmo recomendado
- **3 a 5 historias por día**, no las 70 juntas. Así tenés contenido para 3 o 4 semanas.
- Mejores horarios para dueños y encargados: **10:00 a 12:00** y **15:30 a 18:00** (antes de abrir y antes del servicio). Evitá de 20 a 1, que están trabajando.
- Combinación diaria sugerida: **1 video + 1 tip o "¿Sabías que?" + 1 encuesta o pregunta frecuente**. Las encuestas generan respuestas y las respuestas suben el alcance.
- Las que mejor funcionen (más respuestas y toques en el link), guardalas en una destacada.

---

## Historias en imagen (50)

### Tips para tu local (01 a 10): contenido de valor
Subilas a la mañana. No hace falta link en todas: el valor está en el consejo. Sumá el sticker de link en 1 de cada 3.

| Archivo | Tema |
|---|---|
| 01-tip-01 | Contá la caja en cada cambio de turno |
| 02-tip-02 | El más vendido no siempre es el que más deja |
| 03-tip-03 | Revisá precios contra costos |
| 04-tip-04 | Medí tu ticket promedio |
| 05-tip-05 | Planificá el personal por la hora pico |
| 06-tip-06 | Stock mínimo para lo que no puede faltar |
| 07-tip-07 | Cada empleado con su usuario |
| 08-tip-08 | Una carta corta vende mejor |
| 09-tip-09 | Registrá todos los gastos |
| 10-tip-10 | Respondé los mensajes rápido |

**Extra:** en los tips podés agregar el sticker **Pregunta** ("¿Qué tip querés para la próxima?") para juntar ideas.

### ¿Sabías que? (11 a 20): funciones de Restoga
Siempre con **sticker de link** a restoga.com.

| Archivo | Función |
|---|---|
| 11-sabias-01 | Cobrar por productos |
| 12-sabias-02 | Propinas registradas aparte |
| 13-sabias-03 | Cambiar una mesa de lugar |
| 14-sabias-04 | Cargar productos desde Excel |
| 15-sabias-05 | Reportes del turno noche completo |
| 16-sabias-06 | Usuario y PIN por empleado |
| 17-sabias-07 | La app de mozos no se descarga |
| 18-sabias-08 | Cupones para la tienda online |
| 19-sabias-09 | Exportar ventas a una planilla |
| 20-sabias-10 | Cancelaciones en los reportes |

### Encuestas (21 a 28): **agregá el sticker antes de publicar**
El espacio vacío del medio es para el sticker. Sin el sticker, la historia no tiene sentido.

| Archivo | Sticker | Opciones |
|---|---|---|
| 21-encuesta-01 | Encuesta | "Menos de 15 min" / "Más de media hora" |
| 22-encuesta-02 | Encuesta | "Sí, papelito" / "No, pantalla o impresora" |
| 23-encuesta-03 | Encuesta | "Sí, un clásico" / "Nunca" |
| 24-encuesta-04 | Encuesta | "Sí, clarísimo" / "Ni idea" |
| 25-encuesta-05 | Encuesta | "Sí" / "Todavía no" |
| 26-encuesta-06 | Encuesta | "Sí, todo a mano" / "No" |
| 27-encuesta-07 | **Deslizador** con emoji 📈 | — |
| 28-encuesta-08 | Encuesta | "¡Sí!" / "Más adelante" |

**Después:** a quien vote "¡Sí!" en la 28, escribile por mensaje directo. Desde la historia: deslizá hacia arriba → ves quién votó qué.

### Preguntas frecuentes (29 a 38)
Ideales para una destacada **"Preguntas"**. Con sticker de link en todas.

| Archivo | Pregunta |
|---|---|
| 29-faq-01 | ¿Tengo que instalar algo? |
| 30-faq-02 | ¿Funciona en el celular? |
| 31-faq-03 | ¿Qué impresoras funcionan? |
| 32-faq-04 | ¿Puedo tener varios usuarios? |
| 33-faq-05 | ¿Puedo cargar mis productos de una? |
| 34-faq-06 | ¿Sirve para delivery? |
| 35-faq-07 | ¿Puedo ver las ventas desde casa? |
| 36-faq-08 | ¿Mis clientes necesitan una app para el club? |
| 37-faq-09 | ¿Puedo dividir la cuenta? |
| 38-faq-10 | ¿Cuánto cuesta? (invita a escribir por mensaje directo) |

### Antes y ahora (39 a 44)
Funcionan muy bien de a dos o tres seguidas. Sticker de link en la última.

| Archivo | Tema |
|---|---|
| 39-versus-01 | La comanda |
| 40-versus-02 | El cierre de caja |
| 41-versus-03 | Los precios |
| 42-versus-04 | La cuenta dividida |
| 43-versus-05 | Los números del mes |
| 44-versus-06 | El stock |

### Frases (45 a 50)
Para cerrar el día o para compartir. Podés sumar música tranquila. La 50 ("Tu local, sin vueltas") va con sticker de link.

---

## Historias en video (20)

Son MP4 sin sonido: **agregá música desde Instagram** (ícono de música → buscá algo instrumental y con ritmo; por ejemplo "lo-fi", "funk" o "house" tranquilo). Duran entre 7 y 18 segundos, así que cada una entra en una sola historia.

| Archivo | Qué muestra | Duración | Sticker sugerido |
|---|---|---|---|
| v01-salon-en-vivo | Grabación real del salón en vivo | 18 s | Link |
| v02-tomar-pedido | Grabación: pedido desde el celular | 15 s | Link |
| v03-partes-iguales | Grabación: dividir la cuenta | 16 s | Link |
| v04-quitar-producto | Grabación: quitar un producto del pedido | 7 s | — |
| v05-abrir-caja | Grabación: abrir la caja contando billetes | 11 s | Link |
| v06-cierre-caja | Grabación: cierre de caja | 15 s | Link |
| v07-nuevo-gasto | Grabación: cargar un gasto | 14 s | Link |
| v08-instalar-impresora | Grabación: instalar la impresora | 18 s | Pregunta: "¿Qué impresora tenés?" |
| v09-cocina | Recorrido por la pantalla de cocina | 9 s | Link |
| v10-reportes | Recorrido por los reportes | 9 s | Encuesta: "¿Sabés tu hora pico?" |
| v11-rentabilidad | Zoom a la ganancia por producto | 9 s | Link |
| v12-precios | Zoom al botón de aumento masivo | 9 s | Link |
| v13-caja | Recorrido por los arqueos | 9 s | Link |
| v14-inicio | Panel de inicio | 9 s | Link |
| v15-gastos | Recorrido por gastos | 9 s | Link |
| v16-cobro | Zoom al cobro dividido | 9 s | Link |
| v17-menu-qr | Scroll por el menú QR en el celular | 10 s | Link |
| v18-tienda | Scroll por la tienda online | 10 s | Link |
| v19-club | Club de puntos | 9 s | Link |
| v20-mozo | App de mozos | 9 s | Link |

**Tip:** los videos también sirven como **Reels**. Al subir, elegí "Reel" en vez de "Historia", agregá música y un texto de la tabla de posteos (`TEXTOS.md`). En los Reels la parte de abajo queda tapada por el texto, así que el botón "restoga.com" puede no verse; poné el link en la descripción ("link en la bio").
