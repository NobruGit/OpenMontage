# Perfil de Instagram @resto.ga

La API de Instagram no permite editar el nombre, la biografía, el link ni la foto. Esto se carga a mano desde la app: **Perfil → Editar perfil**. Todo está listo para copiar y pegar.

## Foto de perfil
`restoga-logo-perfil-1080.png` (ya centrado para el recorte circular).

## Nombre
El nombre aparece en las búsquedas, así que conviene que tenga las palabras clave (máximo 64 caracteres):

```
Restoga | Sistema POS gastronómico
```

## Biografía (máximo 150 caracteres; esta tiene 131)

```
Sistema POS en la nube para bares, pizzerías y restós.
Salón, cocina, caja y reportes desde el navegador.
Tu local, sin vueltas. 👇
```

## Link
```
https://restoga.com
```
Título del link (opcional): `Conocé Restoga`

## Opciones de cuenta profesional
- **Categoría:** Software (o "Servicio de software"), con "Mostrar categoría" activado.
- **Botones de contacto:** agregá WhatsApp (el número comercial) y email. En Editar perfil → Opciones de contacto.
- **Botón de acción:** "Reservar" no aplica. Si aparece "Contactar" o "Pedir demo", usalo.

## Historias destacadas
Las portadas están en esta carpeta, en formato 1080×1920. Subí cada una como historia, agregala a la destacada y elegila como portada. Orden sugerido:

| Destacada | Portada | Qué poner |
|---|---|---|
| Cómo funciona | `destacada-como-funciona.png` | Placas 01, 02 y 10 |
| Salón | `destacada-salon.png` | Placas 03, 04 y 17 |
| Cocina | `destacada-cocina.png` | Placas 06 y 07 |
| Caja | `destacada-caja.png` | Placas 05, 08 y 09 |
| Reportes | `destacada-reportes.png` | Placas 11, 12 y 15 |
| Menú QR | `destacada-menu-qr.png` | Placa 18 |
| Tienda | `destacada-tienda.png` | Placa 19 |
| Clientes | `destacada-clientes.png` | Placa 20 y testimonios cuando los haya |

## Ya configurado
Mensajes directos con **preguntas rápidas** (aparecen cuando alguien abre un chat con @resto.ga):
- Quiero probar Restoga en mi local
- ¿Cuánto cuesta?
- ¿Funciona con mi impresora térmica?
- Quiero una demo por videollamada
