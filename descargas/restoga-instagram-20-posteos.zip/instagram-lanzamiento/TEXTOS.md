# Restoga: 20 posteos para Instagram

Formato 4:5 (1080×1350), el que más pantalla ocupa en el feed. Cada placa usa una **captura real del sistema** (local de ejemplo "La Esquina Pizza Bar" con datos de demo) y los colores del logo: rojo `#E30016` (degradado `#FF1F33` → `#CF0016`), grafito `#130E0E`, hueso `#F1EFED` e Inter.

Se armaron con OpenMontage (Remotion). La composición es `RestogaPost` y los textos y recortes están en `remotion-composer/src/restoga/posts.json`.

**Orden sugerido:** el de la numeración. Alterna fondos rojo, oscuro y claro para que la grilla del perfil no quede pareja.

**Hashtags base** (sumar 3 a 5 por posteo): `#gastronomia #bares #pizzerias #restaurantes #puntodeventa #sistemagastronomico #dueñosdebares #gastronomiaargentina`

---

### 01 · Lanzamiento
> Restoga ya está online.
>
> Un sistema de punto de venta en la nube para bares, pizzerías y locales gastronómicos. Salón, cocina, caja, reportes y pedidos online en un solo lugar, desde el navegador.
>
> Sin servidor en el local. Sin instalaciones raras. Sin vueltas.
>
> Conocelo en restoga.com, link en la bio.

### 02 · 5 señales de que tu sistema te frena
> ¿Cuántas te pasaron este mes?
>
> 1. Se cuelga justo un viernes a la noche
> 2. Depende de una PC que nadie se anima a tocar
> 3. Cerrar la caja te lleva más de media hora
> 4. No sabés qué producto te deja más ganancia
> 5. Capacitar a un mozo nuevo es un drama
>
> Si marcaste dos o más, te conviene conocer Restoga. Guardá este posteo y mandáselo a tu socio.

### 03 · Salón en vivo
> El plano de tu salón, en vivo.
>
> Gris: libre. Rojo: ocupada. Azul: pidieron la cuenta. Naranja: pago parcial. En cada mesa ves hace cuánto está abierta y si hay platos listos para llevar.
>
> Sin preguntar ni recorrer el local. restoga.com

### 04 · El pedido en 3 toques
> Tocás la mesa, tocás el producto y confirmás. La comanda ya está en cocina.
>
> Accesos rápidos para lo que más vendés y un buscador que agrega con Enter para todo lo demás. Notas por ítem, descuentos y cambio de mesa sin vueltas.

### 05 · Cobro dividido
> "Yo pago con efectivo y él con Mercado Pago."
>
> En Restoga sumás los medios de pago que hagan falta: el sistema descuenta y te muestra cuánto falta. También podés dividir por productos o en partes iguales, y calcula el vuelto solo.
>
> Cobrar no debería ser la parte difícil de la noche.

### 06 · Pantalla de cocina
> Chau papelitos que se pierden.
>
> La cocina ve las comandas en tres columnas: pendiente, preparando y listo. Suena una alerta cuando entra algo nuevo y avisa si un pedido se está demorando.
>
> Cuando el plato está listo, al mozo le vibra el celular.

### 07 · Impresión directa
> Cada producto sale en la impresora de su sector: pizzas a cocina, tragos a barra, la cuenta a caja.
>
> Funciona con térmicas por red o USB (Hasar, Xprinter y cualquier ESC/POS) y abre el cajón al cobrar en efectivo. Sin ventanas ni preguntas.

### 08 · Arqueos de caja
> $ Sistema. $ Declarado. Diferencia.
>
> Cada turno queda registrado con lo que el sistema esperaba y lo que se contó. Si falta o sobra plata, lo ves al instante y sabés en qué turno pasó.
>
> El control de la caja, sin planillas.

### 09 · Cierre de caja
> Son las 3 de la mañana y hay que cerrar.
>
> Contás los billetes y Restoga suma. Débito, transferencia y Mercado Pago se igualan con un toque. Dejás el fondo para el próximo turno, el sistema calcula el retiro y listo.
>
> Cerraste. Ahora sí, a casa.

### 10 · Panel de inicio
> Lo primero que ves al entrar: ventas de hoy, ticket promedio, pedidos abiertos, mesas ocupadas y lo más pedido de la noche.
>
> Tu local en una pantalla, desde donde estés.

### 11 · Reportes
> ¿Cuál es tu día más fuerte? ¿A qué hora explota el salón? ¿Qué mozo vende más?
>
> Restoga te lo dice: ventas por día y hora, medio de pago, categoría, producto, mozo y tipo de pedido. También podés elegir un rango exacto, como el turno noche del viernes al sábado, y exportar a CSV.
>
> Decidí con números, no a ojo.

### 12 · Márgenes y costos
> Vender mucho no siempre es ganar mucho.
>
> Cargás la receta de cada producto y el costo se calcula solo. Ves cuánto te deja cada pizza, cada trago y cada categoría, y cuál conviene empujar.
>
> ¿Sabés cuál es tu producto más rentable? Contanos en los comentarios.

### 13 · Usuarios y permisos
> Cada uno ve lo suyo. Vos ves todo.
>
> Roles listos para administrador, encargado, cajero, mozo y cocina, con permisos que podés ajustar por persona. Cada uno entra con su usuario y PIN.
>
> El mozo no toca la caja. La cocina ve solo comandas.

### 14 · Stock de ingredientes
> Que no te falte la muzza un sábado.
>
> Cada venta descuenta los ingredientes de la receta y Restoga te avisa cuando algo está por debajo del mínimo. Al cargar las compras a proveedores, también podés sumar ese stock.

### 15 · Precios
> ¿Aumentó todo otra vez?
>
> Con el aumento masivo actualizás la carta por porcentaje, por categoría o completa, en un minuto. Y mientras lo hacés ves el costo y el margen de cada producto, para no vender a pérdida.
>
> El menú QR y la tienda online se actualizan al instante.

### 16 · Gastos y proveedores
> Qué pagaste, qué debés y qué vence.
>
> Registrá compras y gastos, pagalos desde la caja y mirá a quién le debés y cuándo vence. Con el análisis ves en qué se te va la plata cada mes.

### 17 · App de mozos
> El sistema entra en el bolsillo del mozo.
>
> Desde el celular ve las mesas, toma pedidos y recibe el aviso de "pedido listo" con vibración. Se agrega a la pantalla de inicio como una app, sin descargar nada.

### 18 · Menú QR
> La carta, en el celular de tu cliente.
>
> Un QR en la mesa abre tu menú con fotos, descripciones y precios. Si cambiás algo en Restoga, se actualiza al instante. No hay que reimprimir.

### 19 · Tienda online
> Tus pedidos online, directo a la cocina.
>
> Cada local tiene su propia tienda con delivery o retiro, cupones de descuento y seguimiento del pedido en vivo. Los pedidos entran al mismo sistema que usás en el salón.
>
> Compartí el link en tu bio y empezá a recibir pedidos.

### 20 · Club de puntos
> Que vuelvan. Y que vuelvan seguido.
>
> Tus clientes suman puntos con solo decir su celular al pagar y canjean premios con un PIN de 4 números. Sin apps, sin mails, sin activaciones.
>
> Fidelizar también puede ser simple. Conocé Restoga en restoga.com.

---

## Cómo regenerarlas en OpenMontage

`openmontage-restoga.patch` suma la composición `RestogaPost`, `posts.json` y el script de render al fork de OpenMontage (sobre la rama `vueltabar-placas-instagram`):

```bash
git apply openmontage-restoga.patch
# Copiar las capturas (PNG) y assets/img/logo.svg a remotion-composer/public/restoga/
cd remotion-composer && node render-restoga.mjs out/restoga           # las 20
node render-restoga.mjs out/restoga cobro,cierre                         # solo algunas
```

Para cambiar un texto, un recorte o una etiqueta, se edita `posts.json`. Un texto entre `[corchetes]` se pinta con el color de acento.
