# Cómo armar las historias destacadas de @resto.ga

Las 24 historias ya están publicadas en @resto.ga (09/11/2026). **Tenés 24 horas** para agregarlas a destacadas desde las historias activas. Después siguen disponibles en el **Archivo de historias**, así que no se pierden.

Cada historia dice arriba a la derecha a qué destacada va (por ejemplo "CAJA · 2/3").

**Ojo con Clientes 3/3:** hay dos versiones publicadas. Usá la **más nueva** ("¿Querés usarlo en tu local?") y borrá la vieja ("¿Querés verlo en tu local?", la que menciona videollamada): abrila → **Más (···)** → **Eliminar**.

## Qué va en cada destacada

| # | Destacada | Historias (en este orden) | Portada |
|---|---|---|---|
| 1 | Cómo funciona | 01, 02, 03 | `destacada-como-funciona.png` |
| 2 | Salón | 04, 05, 06 | `destacada-salon.png` |
| 3 | Cocina | 07, 08, 09 | `destacada-cocina.png` |
| 4 | Caja | 10, 11, 12 | `destacada-caja.png` |
| 5 | Reportes | 13, 14, 15, 16 | `destacada-reportes.png` |
| 6 | Menú QR | 17, 18 | `destacada-menu-qr.png` |
| 7 | Tienda | 19, 20, 21 | `destacada-tienda.png` |
| 8 | Clientes | 22, 23, 24 | `destacada-clientes.png` |

## Paso a paso (desde el celular)

**Primero, guardá las portadas en el celular.** Bajá el zip, descomprimilo y guardá los 8 archivos `destacada-*.png` en la galería (en iPhone: abrir cada imagen → Compartir → Guardar imagen).

**Crear la primera destacada ("Cómo funciona"):**
1. Entrá a tu perfil @resto.ga.
2. Debajo de la biografía tocá el círculo **"+ Nueva"**. Si no aparece, tocá **"Destacadas"** o deslizá la fila hacia la derecha.
3. Instagram muestra tus historias. Marcá **01, 02 y 03** en ese orden ("¿Qué es Restoga?", "Todo tu local en un solo lugar", "Empezás en 3 pasos").
4. Tocá **Siguiente**.
5. Tocá **Editar portada** → el ícono de **galería** (abajo a la izquierda) → elegí `destacada-como-funciona.png`. Centrala y tocá **Listo**.
6. Escribí el nombre: **Cómo funciona**.
7. Tocá **Agregar** (o **Listo**).

**Repetí con las otras 7** usando la tabla de arriba. Creá las destacadas en orden inverso (empezá por **Clientes** y terminá con **Cómo funciona**) y "Cómo funciona" va a quedar primera a la izquierda, porque Instagram pone la más nueva al principio.

## Si ya pasaron las 24 horas
Perfil → **+ Nueva** → Instagram te muestra el **Archivo** con todas las historias. Elegilas igual que arriba. Si no aparecen: Menú (≡) → **Tu actividad** → **Archivo** → **Archivo de historias** y revisá que esté activado **Guardar historias en el archivo** (Configuración → Archivo y descargas).

## Cambiar algo después
Mantené apretada la destacada → **Editar destacada**. Desde ahí cambiás la portada, el nombre o agregás y sacás historias.

## Los nombres
Instagram muestra unos 10–12 caracteres debajo del círculo. Por eso son cortos: Cómo funciona · Salón · Cocina · Caja · Reportes · Menú QR · Tienda · Clientes.
